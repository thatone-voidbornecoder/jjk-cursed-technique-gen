import { Router, type IRouter } from "express";
import healthRouter from "./health";
import cursedRouter from "./cursed";

const router: IRouter = Router();

router.use(healthRouter);
router.use(cursedRouter);

export default router;
