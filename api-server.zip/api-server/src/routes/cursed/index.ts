import { Router, type IRouter } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";
import { logger } from "../../lib/logger";

const router: IRouter = Router();

function buildCursedTechniquePrompt(
  calm: number,
  logical: number,
  introverted: number,
  strategic: number,
  selfDescription?: string,
  mentor?: string,
  vibeMode?: boolean,
  cursedWeapon?: boolean,
  heavenlyRestriction?: boolean,
): string {
  const calmChaos = calm > 50 ? "chaotic" : "calm";
  const logicEmotion = logical > 50 ? "emotional" : "logical";
  const introExtro = introverted > 50 ? "extroverted" : "introverted";
  const stratImpulse = strategic > 50 ? "impulsive" : "strategic";

  const personalityDesc = selfDescription
    ? `The user describes themselves as: "${selfDescription}". This description MUST visibly shape the technique's naming, flavor, and theme — it should feel like it was written specifically for this person, not a generic technique.`
    : "";

  const mentorContext: Record<string, string> = {
    "Gojo Satoru":
      "Trained under Satoru Gojo. Technique names are flamboyant, confidence-oozing, spatially-minded. Gojo's influence is visible — evocative, slightly theatrical, emphasizing absolute dominance and infinity concepts.",
    "Yaga Masamichi":
      "Trained under Masamichi Yaga. The technique reflects the cursed corpse philosophy — animation, soul, puppet-like constructs. Naming is grounded, craftsman-like, purposeful.",
    "Nanami Kento":
      "Trained under Kento Nanami. The technique is precise, efficient, ratio-based. Naming is professional, clipped, almost corporate. No wasted syllables.",
    "Haibara Yu":
      "Trained under Yu Haibara. The technique reflects earnest cooperation, protective energy, and subtle optimism hidden under a grim exterior. Naming feels human and sincere.",
    "Suguru Geto":
      "Trained under Suguru Geto. Technique has a grand, ideological undertone — this sorcerer believes power is earned and cursed energy is destiny. Naming carries weight and almost religious gravity.",
    "Mei Mei":
      "Trained under Mei Mei. The technique is mercenary, efficient, and unsentimental — designed for maximum output per joule of cursed energy. Naming is sleek and implies profit-minded ruthlessness.",
  };

  const mentorLine =
    mentor && mentorContext[mentor]
      ? `MENTOR INFLUENCE: ${mentorContext[mentor]}`
      : "";

  const vibeLine = vibeMode
    ? "VIBE MODE ACTIVE: Generate a wildly unpredictable, exaggerated, chaotic technique. Push the naming conventions to their extreme. The technique should feel borderline unreasonable but still follow JJK cursed energy logic. Be dramatic and over-the-top."
    : "";

  const heavenlyRestrictionLine = heavenlyRestriction
    ? `HEAVENLY RESTRICTION ACTIVE: This sorcerer has accepted a Heavenly Restriction — they have zero cursed energy (or near-zero). Set cursedEnergyType to "Zero (Heavenly Restriction)". Their innate technique must be purely physical — superhuman speed, strength, perception, or a unique body trait rather than energy manipulation. Domain Expansion is impossible; note this explicitly in the bindingVow field. Grade should reflect their physical prowess compensating for total lack of CE — they can still be Grade 1 or higher based on sheer capability. Reference Toji Fushiguro and Maki Zenin as the canonical precedent for this path.`
    : "";

  const cursedWeaponLine = cursedWeapon
    ? `CURSED WEAPON: This sorcerer wields a cursed tool. Include a "cursedWeaponProfile" field in your JSON with:
- "name": the weapon's proper name in JJK style (e.g. "Playful Cloud", "Split Soul Katana", "Chain of a Thousand Miles")
- "weaponType": the physical form (katana, staff, hammer, spear, chain, bladed gauntlet, nodachi, etc.)
- "grade": the weapon's grade as a cursed tool ("Special Grade Cursed Tool", "Grade 1 Cursed Tool", "Grade 2 Cursed Tool", "Innate Cursed Tool" for tools bound to the user)
- "ability": the weapon's special cursed ability in 1-2 sentences — it should COMPLEMENT the innate technique, not replace it
- "lore": 1 sentence of historical flavor — who made it, what era, any notable previous wielders or battles
This weapon should feel like it belongs in the JJK universe. Reference real examples: Nanami's blunt sword, Maki's Phoenix Robe, Toji's inventory spirit, Yuta's katana, the Playful Cloud.`
    : "";

  const gradeThresholds = `
Determine sorcerer grade based on personality profile:
- Special Grade: Only for extreme combinations. Rare.
- Grade 1: Strong combinations with clear mastery.
- Semi-Grade 1: Above average.
- Grade 2 / Semi-Grade 2: Average sorcerers.
- Grade 3 / Grade 4: Weaker or underdeveloped techniques.
Personality values: calm=${calm}/100 (100=chaotic), logical=${logical}/100 (100=emotional), introverted=${introverted}/100 (100=extroverted), strategic=${strategic}/100 (100=impulsive).
`;

  const weaponJsonField = cursedWeapon
    ? `,
  "cursedWeaponProfile": {
    "name": "Weapon name",
    "weaponType": "physical form",
    "grade": "Grade designation",
    "ability": "Cursed ability description",
    "lore": "Historical lore"
  }`
    : "";

  return `You are writing official Jujutsu Kaisen lore. Generate a complete cursed technique profile for a sorcerer with this personality:
- Calm/Chaotic: ${calm}/100 (higher = more chaotic) — personality is ${calmChaos}
- Logical/Emotional: ${logical}/100 (higher = more emotional) — personality is ${logicEmotion}
- Introverted/Extroverted: ${introverted}/100 (higher = more extroverted) — personality is ${introExtro}
- Strategic/Impulsive: ${strategic}/100 (higher = more impulsive) — personality is ${stratImpulse}

${personalityDesc}
${mentorLine}
${vibeLine}
${heavenlyRestrictionLine}
${cursedWeaponLine}
${gradeThresholds}

CRITICAL: Write in authentic JJK style. Reference actual JJK logic: cursed energy flow, black flash potential, reverse cursed technique compatibility, binding vow mechanics, domain sure-hit environments. AVOID generic fantasy language. Naming must feel anime-authentic, not Western fantasy.

Return ONLY valid JSON in this exact structure. No markdown, no code blocks, just raw JSON:
{
  "cursedEnergyType": "string — e.g. 'Spatial Distortion' or 'Necrotic Resonance' or 'Gravity-Well Emission'",
  "innateTechnique": {
    "name": "Technique name in JJK style — often a poetic or clinical phrase",
    "description": "2-3 sentences of lore-accurate description. Reference how the cursed energy manifests physically, how it interacts with the user's body, and what its base limitation is."
  },
  "extensionTechniques": [
    {
      "name": "Extension technique name",
      "description": "How this technique extends or refines the innate technique. Name it like JJK would: 'Simple Domain → Falling Blossom Emotion' style. Include cursed energy cost or trigger condition."
    },
    {
      "name": "Second extension technique name",
      "description": "Description."
    },
    {
      "name": "Third extension technique name (most powerful)",
      "description": "Description — this should be a culmination of the innate technique taken to its limit."
    }
  ],
  "domainExpansion": {
    "name": "Domain name — in JJK style: two-part poetic name like 'Infinite Void', 'Malevolent Shrine', 'Coffin of the Iron Mountain'. MUST be original.",
    "description": "2-3 sentences. Describe the sure-hit environment it creates, its visual appearance, and what makes it devastating. Reference how cursed energy saturates the space."
  },
  "bindingVow": "The cost or limitation the user accepted to maximize output. Reference binding vow mechanics: 'By revealing the technique in advance...', 'By accepting damage to the body...', 'By limiting the domain to X seconds...'. Keep it specific and consequential.",
  "techniqueWeakness": "What type of technique or approach counters this. Be specific.",
  "reverseCursedTechnique": "One sentence describing whether this sorcerer can use Reverse Cursed Technique for healing, and at what cost or limitation. E.g. 'Limited RCT — can heal surface wounds but lacks the precision for organ reconstruction.' Or 'No RCT compatibility — the cursed energy flow is too unidirectional to reverse.'",
  "sorcererGrade": "One of: Special Grade, Grade 1, Semi-Grade 1, Grade 2, Semi-Grade 2, Grade 3, Grade 4",
  "clanAffiliation": "One of: Tokyo Jujutsu High, Kyoto Jujutsu High, Independent Sorcerer, Zenin Clan, Gojo Clan, Kamo Clan, Cursed Spirit User, Unaffiliated",
  "tengenNarration": "Tengen's assessment in his canonical voice. 2-3 paragraphs. His register: detached, formal, ancient, almost bureaucratic. Examples of his phrasing: 'This technique operates on the principle of...', 'In recorded history, only...', 'The cursed energy output required renders this technique...' He discusses both the innate technique and the domain. If the sorcererGrade is 'Special Grade', end with a new paragraph containing ONLY the exact phrase: '...with the sole exception of Satoru Gojo, of course.' — otherwise do not include this phrase.",
  "includeGojoException": true or false — true ONLY if sorcererGrade is 'Special Grade'${weaponJsonField}
}`;
}

function buildClashPrompt(technique1: string, technique2: string): string {
  return `You are writing official Jujutsu Kaisen lore. Two sorcerers with the following cursed techniques are clashing. Analyze their interaction and produce a combination/clash profile.

TECHNIQUE 1:
${technique1}

TECHNIQUE 2:
${technique2}

Write in authentic JJK style. Reference actual JJK logic: cursed energy flow, domain interactions, binding vow conflicts, reverse cursed technique compatibility, black flash potential.

Return ONLY valid JSON in this exact structure. No markdown, no code blocks, just raw JSON:
{
  "comboName": "A name for this technique combination or clash — in JJK naming style",
  "interactionExplanation": "3-4 sentences explaining how these two techniques interact. Do they amplify, conflict, counter, or create emergent effects? Reference specific cursed energy mechanics.",
  "tengenClashNarration": "Tengen's assessment of this clash in his canonical voice. 2 paragraphs. Detached, formal, ancient, bureaucratic. He assesses whether this clash has historical precedent and what the theoretical outcome would be."
}`;
}

router.post("/cursed/generate", async (req, res): Promise<void> => {
  const { calm, logical, introverted, strategic, selfDescription, mentor, vibeMode, cursedWeapon, heavenlyRestriction } =
    req.body;

  if (
    typeof calm !== "number" ||
    typeof logical !== "number" ||
    typeof introverted !== "number" ||
    typeof strategic !== "number"
  ) {
    res.status(400).json({ error: "Missing required personality values" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const prompt = buildCursedTechniquePrompt(
      calm,
      logical,
      introverted,
      strategic,
      selfDescription,
      mentor,
      vibeMode,
      cursedWeapon,
      heavenlyRestriction,
    );

    let fullResponse = "";

    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 8192,
      messages: [{ role: "user", content: prompt }],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
      }
    }

    try {
      const parsed = JSON.parse(fullResponse);
      res.write(`data: ${JSON.stringify(parsed)}\n\n`);
    } catch {
      const jsonMatch = fullResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        res.write(`data: ${JSON.stringify(parsed)}\n\n`);
      } else {
        res.write(
          `data: ${JSON.stringify({ error: "Failed to parse response" })}\n\n`,
        );
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    logger.error({ err }, "Error generating cursed technique");
    res.write(`data: ${JSON.stringify({ error: "Generation failed" })}\n\n`);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  }
});

router.post("/cursed/clash", async (req, res): Promise<void> => {
  const { technique1, technique2 } = req.body;

  if (!technique1 || !technique2) {
    res.status(400).json({ error: "Both technique profiles are required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const prompt = buildClashPrompt(technique1, technique2);

    let fullResponse = "";

    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 4096,
      messages: [{ role: "user", content: prompt }],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
      }
    }

    try {
      const parsed = JSON.parse(fullResponse);
      res.write(`data: ${JSON.stringify(parsed)}\n\n`);
    } catch {
      const jsonMatch = fullResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        res.write(`data: ${JSON.stringify(parsed)}\n\n`);
      } else {
        res.write(
          `data: ${JSON.stringify({ error: "Failed to parse clash response" })}\n\n`,
        );
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    logger.error({ err }, "Error clashing cursed techniques");
    res.write(`data: ${JSON.stringify({ error: "Clash analysis failed" })}\n\n`);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  }
});

export default router;
