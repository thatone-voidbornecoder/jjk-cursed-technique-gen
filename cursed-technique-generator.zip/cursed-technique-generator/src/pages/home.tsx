import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useGenerator } from "@/hooks/use-generator";
import type { CursedTechniqueProfile, ClashResult } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import html2canvas from "html2canvas";
import { Download, History, Zap, Sparkles, RefreshCw, Copy, Link2, Trash2, BookOpen, Sword, Shield } from "lucide-react";

const LS_HISTORY_KEY = "ctg_history";
const LS_CURRENT_KEY = "ctg_current_profile";

function encodeProfileToURL(profile: CursedTechniqueProfile): string {
  try {
    const encoded = btoa(encodeURIComponent(JSON.stringify(profile)));
    const url = new URL(window.location.href);
    url.searchParams.set("technique", encoded);
    return url.toString();
  } catch {
    return window.location.href;
  }
}

function decodeProfileFromURL(): CursedTechniqueProfile | null {
  try {
    const params = new URLSearchParams(window.location.search);
    const encoded = params.get("technique");
    if (!encoded) return null;
    return JSON.parse(decodeURIComponent(atob(encoded)));
  } catch {
    return null;
  }
}

function formatProfileAsText(profile: CursedTechniqueProfile): string {
  const lines = [
    `╔══════════════════════════════════╗`,
    `     CURSED TECHNIQUE GENERATOR`,
    `╚══════════════════════════════════╝`,
    ``,
    `CURSED ENERGY TYPE`,
    profile.cursedEnergyType,
    ``,
    `INNATE TECHNIQUE: ${profile.innateTechnique.name}`,
    profile.innateTechnique.description,
    ``,
    `EXTENSION TECHNIQUES`,
    ...profile.extensionTechniques.map((e) => `• ${e.name}: ${e.description}`),
    ``,
    `DOMAIN EXPANSION: ${profile.domainExpansion.name}`,
    profile.domainExpansion.description,
    ``,
    `BINDING VOW`,
    profile.bindingVow,
    ``,
    `TECHNIQUE WEAKNESS`,
    profile.techniqueWeakness,
  ];
  if (profile.reverseCursedTechnique) {
    lines.push(``, `REVERSE CURSED TECHNIQUE`, profile.reverseCursedTechnique);
  }
  if (profile.cursedWeaponProfile) {
    const w = profile.cursedWeaponProfile;
    lines.push(
      ``,
      `CURSED WEAPON: ${w.name} (${w.weaponType})`,
      `Grade: ${w.grade}`,
      `Ability: ${w.ability}`,
      `Lore: ${w.lore}`,
    );
  }
  lines.push(
    ``,
    `SORCERER GRADE: ${profile.sorcererGrade}`,
    `AFFILIATION: ${profile.clanAffiliation}`,
    ``,
    `— TENGEN'S ASSESSMENT —`,
    `"${profile.tengenNarration}"`,
  );
  if (profile.includeGojoException && profile.sorcererGrade === "Special Grade") {
    lines.push(`"...with the sole exception of Satoru Gojo, of course."`);
  }
  return lines.join("\n");
}

export default function Home() {
  const [calm, setCalm] = useState([50]);
  const [logical, setLogical] = useState([50]);
  const [introverted, setIntroverted] = useState([50]);
  const [strategic, setStrategic] = useState([50]);
  const [selfDescription, setSelfDescription] = useState("");
  const [mentor, setMentor] = useState("Gojo Satoru");
  const [vibeMode, setVibeMode] = useState(false);
  const [cursedWeapon, setCursedWeapon] = useState(false);
  const [heavenlyRestriction, setHeavenlyRestriction] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);

  const [history, setHistory] = useState<CursedTechniqueProfile[]>(() => {
    try {
      const saved = localStorage.getItem(LS_HISTORY_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentProfile, setCurrentProfile] = useState<CursedTechniqueProfile | null>(() => {
    const fromURL = decodeProfileFromURL();
    if (fromURL) return fromURL;
    try {
      const saved = localStorage.getItem(LS_CURRENT_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [clashTarget, setClashTarget] = useState("");
  const [clashResult, setClashResult] = useState<ClashResult | null>(null);

  const { generateTechnique, clashTechniques, isGenerating, isClashing } = useGenerator();
  const { toast } = useToast();
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(LS_HISTORY_KEY, JSON.stringify(history));
    } catch {}
  }, [history]);

  useEffect(() => {
    try {
      if (currentProfile) {
        localStorage.setItem(LS_CURRENT_KEY, JSON.stringify(currentProfile));
      }
    } catch {}
  }, [currentProfile]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has("technique")) {
      const url = new URL(window.location.href);
      url.searchParams.delete("technique");
      window.history.replaceState({}, "", url.toString());
    }
  }, []);

  // When Heavenly Restriction is on, weapon is irrelevant
  useEffect(() => {
    if (heavenlyRestriction) setCursedWeapon(false);
  }, [heavenlyRestriction]);

  const handleRandomize = () => {
    setCalm([Math.floor(Math.random() * 101)]);
    setLogical([Math.floor(Math.random() * 101)]);
    setIntroverted([Math.floor(Math.random() * 101)]);
    setStrategic([Math.floor(Math.random() * 101)]);
  };

  const handleGenerate = async () => {
    setClashResult(null);
    setCurrentProfile(null);
    const profile = await generateTechnique({
      calm: calm[0],
      logical: logical[0],
      introverted: introverted[0],
      strategic: strategic[0],
      selfDescription,
      mentor,
      vibeMode,
      cursedWeapon,
      heavenlyRestriction,
    });
    if (profile) {
      setCurrentProfile(profile);
      setHistory((prev) => {
        const deduped = prev.filter((p) => p.id !== profile.id);
        return [profile, ...deduped].slice(0, 10);
      });
    }
  };

  const handleClash = async () => {
    if (!currentProfile || !clashTarget.trim()) return;
    let targetProfile: CursedTechniqueProfile;
    try {
      targetProfile = JSON.parse(clashTarget);
    } catch {
      toast({ title: "Invalid JSON", description: "Paste a valid technique profile JSON.", variant: "destructive" });
      return;
    }
    const result = await clashTechniques(currentProfile, targetProfile);
    if (result) setClashResult(result);
  };

  const handleCopyProfile = useCallback(() => {
    if (!currentProfile) return;
    navigator.clipboard.writeText(formatProfileAsText(currentProfile)).then(() => {
      toast({ title: "Copied", description: "Technique copied to clipboard." });
    }).catch(() => {
      toast({ title: "Error", description: "Could not copy to clipboard.", variant: "destructive" });
    });
  }, [currentProfile, toast]);

  const handleShareLink = useCallback(() => {
    if (!currentProfile) return;
    navigator.clipboard.writeText(encodeProfileToURL(currentProfile)).then(() => {
      toast({ title: "Link copied", description: "Share this link to show your technique." });
    }).catch(() => {
      toast({ title: "Error", description: "Could not copy link.", variant: "destructive" });
    });
  }, [currentProfile, toast]);

  const handleDeleteFromHistory = (id: string) => {
    setHistory((prev) => prev.filter((p) => p.id !== id));
  };

  const exportImage = async () => {
    if (!outputRef.current) return;
    try {
      const canvas = await html2canvas(outputRef.current, {
        backgroundColor: "#0a0a12",
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement("a");
      link.download = `cursed-technique-${Date.now()}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
      toast({ title: "Saved", description: "Technique card exported as image." });
    } catch {
      toast({ title: "Error", description: "Could not export image.", variant: "destructive" });
    }
  };

  const sliders = [
    { label: ["Calm", "Chaotic"], value: calm, setter: setCalm },
    { label: ["Logical", "Emotional"], value: logical, setter: setLogical },
    { label: ["Introverted", "Extroverted"], value: introverted, setter: setIntroverted },
    { label: ["Strategic", "Impulsive"], value: strategic, setter: setStrategic },
  ];

  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground pb-20 overflow-x-hidden selection:bg-primary/30">

      {/* Header */}
      <header className="pt-12 pb-8 px-4 text-center z-10 relative">
        <h1 className="font-serif text-4xl md:text-6xl font-bold tracking-tight neon-glow mb-3">
          Cursed Technique Generator
        </h1>
        <p className="text-muted-foreground font-medium uppercase tracking-widest text-sm md:text-base">
          Discover your innate cursed energy
        </p>
      </header>

      <main className="max-w-4xl mx-auto px-4 space-y-12 relative z-10">

        {/* INPUT SECTION */}
        <Card className="glass-card border-none bg-black/40">
          <CardContent className="p-6 md:p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

              {/* Sliders */}
              <div className="space-y-6">
                {sliders.map(({ label, value, setter }) => (
                  <div key={label[0]} className="space-y-3">
                    <div className="flex justify-between text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      <span>{label[0]}</span>
                      <span>{label[1]}</span>
                    </div>
                    <Slider
                      value={value}
                      onValueChange={setter}
                      max={100}
                      step={1}
                      className="[&_[role=slider]]:shadow-[0_0_10px_rgba(139,92,246,0.8)] [&_[role=slider]]:border-primary"
                    />
                  </div>
                ))}
              </div>

              {/* Right column controls */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="desc" className="text-muted-foreground uppercase text-xs font-semibold tracking-wider">
                    Describe yourself in one sentence
                  </Label>
                  <Input
                    id="desc"
                    placeholder="E.g., I overthink every small detail until I freeze."
                    value={selfDescription}
                    onChange={(e) => setSelfDescription(e.target.value)}
                    className="bg-background/50 border-white/10 focus-visible:ring-primary/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground uppercase text-xs font-semibold tracking-wider">Trained under...</Label>
                  <Select value={mentor} onValueChange={setMentor}>
                    <SelectTrigger className="bg-background/50 border-white/10">
                      <SelectValue placeholder="Select mentor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Gojo Satoru">Gojo Satoru</SelectItem>
                      <SelectItem value="Nanami Kento">Nanami Kento</SelectItem>
                      <SelectItem value="Yaga Masamichi">Yaga Masamichi</SelectItem>
                      <SelectItem value="Haibara Yu">Haibara Yu</SelectItem>
                      <SelectItem value="Suguru Geto">Suguru Geto</SelectItem>
                      <SelectItem value="Mei Mei">Mei Mei</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Toggle row */}
                <div className="space-y-2">
                  {/* Vibe Mode */}
                  <div className="flex items-center justify-between px-4 py-3 rounded-md bg-white/5 border border-white/10">
                    <div>
                      <Label className={`text-sm font-bold uppercase tracking-wider ${vibeMode ? "text-red-400" : "text-foreground"}`}>
                        Vibe Mode
                      </Label>
                      <p className="text-xs text-muted-foreground">Chaotic, exaggerated manifestations</p>
                    </div>
                    <Switch
                      checked={vibeMode}
                      onCheckedChange={setVibeMode}
                      className={vibeMode ? "data-[state=checked]:bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.6)]" : ""}
                    />
                  </div>

                  {/* Cursed Weapon */}
                  <div className={`flex items-center justify-between px-4 py-3 rounded-md border transition-colors ${cursedWeapon ? "bg-amber-950/30 border-amber-700/40" : "bg-white/5 border-white/10"} ${heavenlyRestriction ? "opacity-40 pointer-events-none" : ""}`}>
                    <div>
                      <Label className={`text-sm font-bold uppercase tracking-wider flex items-center gap-2 ${cursedWeapon ? "text-amber-400" : "text-foreground"}`}>
                        <Sword className="w-3.5 h-3.5" /> Cursed Weapon Wielder
                      </Label>
                      <p className="text-xs text-muted-foreground">Generate a cursed tool alongside your technique</p>
                    </div>
                    <Switch
                      checked={cursedWeapon}
                      onCheckedChange={setCursedWeapon}
                      disabled={heavenlyRestriction}
                      className={cursedWeapon ? "data-[state=checked]:bg-amber-600 shadow-[0_0_12px_rgba(217,119,6,0.5)]" : ""}
                    />
                  </div>

                  {/* Heavenly Restriction */}
                  <div className={`flex items-center justify-between px-4 py-3 rounded-md border transition-colors ${heavenlyRestriction ? "bg-cyan-950/30 border-cyan-700/40" : "bg-white/5 border-white/10"}`}>
                    <div>
                      <Label className={`text-sm font-bold uppercase tracking-wider flex items-center gap-2 ${heavenlyRestriction ? "text-cyan-400" : "text-foreground"}`}>
                        <Shield className="w-3.5 h-3.5" /> Heavenly Restriction
                      </Label>
                      <p className="text-xs text-muted-foreground">Sacrifice cursed energy for physical perfection</p>
                    </div>
                    <Switch
                      checked={heavenlyRestriction}
                      onCheckedChange={setHeavenlyRestriction}
                      className={heavenlyRestriction ? "data-[state=checked]:bg-cyan-600 shadow-[0_0_12px_rgba(6,182,212,0.5)]" : ""}
                    />
                  </div>
                </div>

                <Button
                  variant="outline"
                  onClick={handleRandomize}
                  className="w-full border-white/10 hover:bg-white/5 text-muted-foreground"
                >
                  <Sparkles className="w-4 h-4 mr-2" /> Randomize Traits
                </Button>
              </div>
            </div>

            <div className="pt-4">
              <Button
                size="lg"
                className={`w-full h-16 text-lg font-serif tracking-widest ${isGenerating ? "cursed-energy-pulse bg-primary/80" : "bg-primary hover:bg-primary/90"} shadow-[0_0_20px_rgba(139,92,246,0.3)] transition-all relative overflow-hidden`}
                onClick={handleGenerate}
                disabled={isGenerating}
              >
                {isGenerating && (
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                    animate={{ x: ["-100%", "200%"] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                  />
                )}
                {isGenerating ? "CHANNELING CURSED ENERGY..." : "GENERATE TECHNIQUE"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* OUTPUT SECTION */}
        <AnimatePresence mode="wait">
          {currentProfile && !isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -40 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="space-y-12"
            >
              <div ref={outputRef} className="space-y-6 bg-background pb-8 pt-4">

                {/* Header badges */}
                <div className="flex flex-wrap items-start gap-3 mb-8 border-b border-white/10 pb-4">
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 px-4 py-1.5 text-sm uppercase tracking-widest shadow-[0_0_10px_rgba(139,92,246,0.2)] whitespace-normal break-words max-w-full">
                    Energy: {currentProfile.cursedEnergyType}
                  </Badge>
                  {currentProfile.clanAffiliation && currentProfile.clanAffiliation !== "None" && (
                    <Badge variant="secondary" className="px-4 py-1.5 text-sm uppercase tracking-widest bg-white/5 whitespace-normal break-words">
                      {currentProfile.clanAffiliation}
                    </Badge>
                  )}
                  {currentProfile.cursedWeaponProfile && (
                    <Badge className="px-4 py-1.5 text-sm uppercase tracking-widest bg-amber-900/40 text-amber-400 border border-amber-700/40 whitespace-normal break-words">
                      <Sword className="w-3 h-3 mr-1.5 inline" /> {currentProfile.cursedWeaponProfile.name}
                    </Badge>
                  )}
                </div>

                {/* Innate Technique */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-2">Innate Technique</h3>
                  <h2 className="font-serif text-3xl md:text-5xl font-bold neon-glow mb-4 text-white break-words">
                    {currentProfile.innateTechnique.name}
                  </h2>
                  <p className="text-lg text-gray-300 leading-relaxed border-l-2 border-primary pl-4 py-1">
                    {currentProfile.innateTechnique.description}
                  </p>
                </motion.div>

                {/* Extension Techniques */}
                <motion.div
                  className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  {currentProfile.extensionTechniques.map((ext, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/10 p-5 rounded-lg">
                      <h4 className="font-serif text-xl font-bold text-accent mb-2 break-words">{ext.name}</h4>
                      <p className="text-sm text-gray-400">{ext.description}</p>
                    </div>
                  ))}
                </motion.div>

                {/* Cursed Weapon Card */}
                {currentProfile.cursedWeaponProfile && (
                  <motion.div
                    className="mt-8 relative overflow-hidden rounded-xl border border-amber-700/40 bg-amber-950/20 p-8 shadow-[0_0_30px_rgba(217,119,6,0.1)]"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                  >
                    <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
                    <div className="flex items-center gap-3 mb-4">
                      <Sword className="w-5 h-5 text-amber-400" />
                      <h3 className="text-sm font-bold uppercase tracking-widest text-amber-400">Cursed Weapon</h3>
                      <span className="text-xs text-amber-700 border border-amber-800/50 rounded px-2 py-0.5 ml-auto">
                        {currentProfile.cursedWeaponProfile.grade}
                      </span>
                    </div>
                    <h2 className="font-serif text-3xl font-black text-white mb-1 break-words" style={{ textShadow: "0 0 15px rgba(217,119,6,0.4)" }}>
                      {currentProfile.cursedWeaponProfile.name}
                    </h2>
                    <p className="text-xs text-amber-700 uppercase tracking-widest mb-4">{currentProfile.cursedWeaponProfile.weaponType}</p>
                    <p className="text-base text-gray-300 mb-3 relative z-10">{currentProfile.cursedWeaponProfile.ability}</p>
                    <p className="text-sm text-gray-500 italic border-l border-amber-800/40 pl-4">
                      {currentProfile.cursedWeaponProfile.lore}
                    </p>
                  </motion.div>
                )}

                {/* Domain Expansion */}
                <motion.div
                  className="mt-8 relative overflow-hidden rounded-xl border border-primary/40 bg-black/60 p-8 shadow-[0_0_30px_rgba(139,92,246,0.15)]"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6, duration: 0.5 }}
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
                  <h3 className="text-sm font-bold uppercase tracking-widest text-primary mb-2">Domain Expansion</h3>
                  <h2 className="font-serif text-4xl md:text-5xl font-black text-white mb-4 tracking-wide break-words" style={{ textShadow: "0 0 20px rgba(139,92,246,0.5)" }}>
                    {currentProfile.domainExpansion.name}
                  </h2>
                  <p className="text-base md:text-lg text-gray-300 relative z-10">
                    {currentProfile.domainExpansion.description}
                  </p>
                </motion.div>

                {/* Binding Vow + Weakness */}
                <motion.div
                  className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  <div className="p-6 border border-destructive/30 bg-destructive/5 rounded-lg relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-destructive" />
                    <h4 className="font-bold uppercase tracking-widest text-destructive text-sm mb-3">Binding Vow</h4>
                    <p className="text-sm text-gray-300">{currentProfile.bindingVow}</p>
                  </div>
                  <div className="p-6 border border-white/10 bg-white/5 rounded-lg relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-muted-foreground" />
                    <h4 className="font-bold uppercase tracking-widest text-muted-foreground text-sm mb-3">Technique Weakness</h4>
                    <p className="text-sm text-gray-300">{currentProfile.techniqueWeakness}</p>
                  </div>
                </motion.div>

                {/* Reverse Cursed Technique */}
                {currentProfile.reverseCursedTechnique && (
                  <motion.div
                    className="p-5 border border-emerald-800/30 bg-emerald-950/10 rounded-lg relative overflow-hidden"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.9 }}
                  >
                    <div className="absolute top-0 left-0 w-1 h-full bg-emerald-600" />
                    <h4 className="font-bold uppercase tracking-widest text-emerald-500 text-sm mb-2">Reverse Cursed Technique</h4>
                    <p className="text-sm text-gray-300">{currentProfile.reverseCursedTechnique}</p>
                  </motion.div>
                )}

                {/* Sorcerer Grade */}
                <motion.div
                  className="mt-12 flex flex-col items-center justify-center py-10 border-y border-white/10"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.0 }}
                >
                  <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-6">Assigned Grade</h3>
                  <div className="relative h-20 w-full max-w-sm flex items-center justify-center overflow-hidden">
                    <motion.div
                      initial={{ rotateX: 90, opacity: 0 }}
                      animate={{ rotateX: 0, opacity: 1 }}
                      transition={{ delay: 1.5, type: "spring", stiffness: 100, damping: 10 }}
                      className="text-4xl md:text-5xl font-serif font-black neon-glow text-white text-center"
                    >
                      {currentProfile.sorcererGrade}
                    </motion.div>
                  </div>
                </motion.div>

              </div>

              {/* Action buttons */}
              <motion.div
                className="flex flex-wrap justify-end gap-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.8 }}
              >
                <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={handleCopyProfile}>
                  <Copy className="w-4 h-4 mr-2" /> Copy Profile
                </Button>
                <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={handleShareLink}>
                  <Link2 className="w-4 h-4 mr-2" /> Share Link
                </Button>
                <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={exportImage}>
                  <Download className="w-4 h-4 mr-2" /> Save Image
                </Button>
              </motion.div>

              {/* Tengen Narration */}
              <motion.div
                className="tengen-scroll rounded-sm p-8 md:p-12 relative my-16"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 2.0, duration: 0.8 }}
              >
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-[#2a2a2a] rounded-b-md" />
                <h3 className="font-serif text-center text-[#8a8a8a] uppercase tracking-[0.3em] text-xs mb-8">
                  Master Tengen's Assessment
                </h3>
                <p className="font-serif text-lg md:text-xl leading-loose text-[#d0c6b8] italic text-center max-w-2xl mx-auto">
                  "{currentProfile.tengenNarration}"
                </p>
                {currentProfile.includeGojoException && currentProfile.sorcererGrade === "Special Grade" && (
                  <p className="font-serif text-sm md:text-base mt-6 text-center text-[#a09688] italic">
                    "...with the sole exception of Satoru Gojo, of course."
                  </p>
                )}
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-[#2a2a2a] rounded-t-md" />
              </motion.div>

              {/* Clash Section */}
              <motion.div
                className="pt-12 border-t border-white/10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.2 }}
              >
                <h2 className="font-serif text-2xl font-bold mb-6 flex items-center gap-3">
                  <Zap className="w-6 h-6 text-accent" /> Technique Clash
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  <div className="md:col-span-5 bg-white/5 rounded-lg p-6 border border-white/10">
                    <h3 className="font-bold text-lg mb-1 text-primary break-words">
                      {currentProfile.innateTechnique.name}
                    </h3>
                    <p className="text-sm text-gray-400">Your current technique</p>
                  </div>

                  <div className="md:col-span-2 flex justify-center items-center h-full text-4xl font-black font-serif text-white/20">
                    VS
                  </div>

                  <div className="md:col-span-5 space-y-3">
                    <Label className="text-muted-foreground uppercase text-xs font-semibold tracking-wider">
                      Opponent — paste JSON or load from history
                    </Label>
                    <Textarea
                      value={clashTarget}
                      onChange={(e) => setClashTarget(e.target.value)}
                      placeholder="Paste a technique JSON here, or load one from History..."
                      className="h-32 font-mono text-xs bg-black/50 border-white/10"
                    />
                  </div>
                </div>

                <div className="mt-8 text-center">
                  <Button
                    size="lg"
                    onClick={handleClash}
                    disabled={isClashing || !clashTarget.trim()}
                    className="bg-accent hover:bg-accent/80 text-black font-bold px-12"
                  >
                    {isClashing ? <RefreshCw className="w-5 h-5 animate-spin" /> : "INITIATE CLASH"}
                  </Button>
                </div>

                <AnimatePresence>
                  {clashResult && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="mt-12 p-8 border border-accent/30 bg-accent/5 rounded-xl"
                    >
                      <h3 className="font-serif text-3xl font-bold text-center mb-2 text-accent break-words">
                        {clashResult.comboName}
                      </h3>
                      <div className="max-w-2xl mx-auto mt-8 space-y-6">
                        <div className="p-4 bg-black/40 rounded border border-white/5">
                          <p className="text-gray-300 leading-relaxed">{clashResult.interactionExplanation}</p>
                        </div>
                        <div className="tengen-scroll p-6 rounded text-center font-serif italic text-[#d0c6b8]">
                          "{clashResult.tengenClashNarration}"
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>

            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* History Panel */}
      <div className="fixed bottom-6 right-6 z-50">
        <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
          <DialogTrigger asChild>
            <Button
              size="icon"
              className="w-14 h-14 rounded-full bg-black border border-white/20 shadow-xl hover:bg-white/10 hover:border-primary/50 transition-colors relative"
            >
              <History className="w-6 h-6 text-primary" />
              {history.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary text-white text-[10px] font-bold flex items-center justify-center">
                  {history.length}
                </span>
              )}
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#111] border-white/10 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="font-serif text-2xl text-primary flex items-center gap-2">
                <BookOpen className="w-5 h-5" /> Saved Techniques
              </DialogTitle>
            </DialogHeader>
            {history.length === 0 ? (
              <p className="text-center text-muted-foreground py-8 text-sm">No techniques saved yet. Generate one to begin.</p>
            ) : (
              <ScrollArea className="h-[60vh] mt-4 pr-4">
                <div className="space-y-4">
                  {history.map((prof) => (
                    <Card
                      key={prof.id}
                      className={`bg-white/5 border transition-colors ${currentProfile?.id === prof.id ? "border-primary/50 shadow-[0_0_10px_rgba(139,92,246,0.2)]" : "border-white/10"}`}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-1 gap-2">
                          <h4 className="font-serif font-bold text-base break-words flex-1">
                            {prof.innateTechnique.name}
                          </h4>
                          <Badge variant="outline" className="text-xs shrink-0">{prof.sorcererGrade}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mb-1 line-clamp-1">{prof.cursedEnergyType}</p>
                        {prof.cursedWeaponProfile && (
                          <p className="text-xs text-amber-600 mb-2 flex items-center gap-1">
                            <Sword className="w-3 h-3" /> {prof.cursedWeaponProfile.name}
                          </p>
                        )}
                        <div className="flex gap-2 mt-3">
                          <Button
                            size="sm"
                            variant="secondary"
                            className="flex-1 text-xs"
                            onClick={() => {
                              setCurrentProfile(prof);
                              setClashResult(null);
                              setHistoryOpen(false);
                            }}
                          >
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 text-xs border-accent/30 text-accent hover:bg-accent/10 hover:text-accent"
                            onClick={() => {
                              setClashTarget(JSON.stringify(prof, null, 2));
                              setHistoryOpen(false);
                            }}
                          >
                            Load to Clash
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 px-2"
                            onClick={() => handleDeleteFromHistory(prof.id)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {/* Ambient background */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/5 blur-[120px] rounded-full" />
      </div>
    </div>
  );
}
