export type CursedWeaponProfile = {
  name: string;
  weaponType: string;
  grade: string;
  ability: string;
  lore: string;
};

export type CursedTechniqueProfile = {
  id: string;
  timestamp: number;
  cursedEnergyType: string;
  innateTechnique: { name: string; description: string };
  extensionTechniques: { name: string; description: string }[];
  domainExpansion: { name: string; description: string };
  bindingVow: string;
  techniqueWeakness: string;
  reverseCursedTechnique?: string;
  sorcererGrade: string;
  clanAffiliation: string;
  tengenNarration: string;
  includeGojoException: boolean;
  cursedWeaponProfile?: CursedWeaponProfile;
};

export type ClashResult = {
  comboName: string;
  interactionExplanation: string;
  tengenClashNarration: string;
};

export type GenerateParams = {
  calm: number;
  logical: number;
  introverted: number;
  strategic: number;
  selfDescription: string;
  mentor: string;
  vibeMode: boolean;
  cursedWeapon: boolean;
  heavenlyRestriction: boolean;
};
