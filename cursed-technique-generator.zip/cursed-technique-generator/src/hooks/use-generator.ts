import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import type { CursedTechniqueProfile, ClashResult, GenerateParams } from "@/lib/types";

function parseSSEEvents(fullText: string): unknown[] {
  const results: unknown[] = [];
  const lines = fullText.split('\n');
  for (const line of lines) {
    if (line.startsWith('data: ')) {
      const data = line.slice(6).trim();
      if (!data || data === '[DONE]') continue;
      try {
        results.push(JSON.parse(data));
      } catch {
        // ignore partial or malformed
      }
    }
  }
  return results;
}

function isValidProfile(obj: unknown): obj is CursedTechniqueProfile {
  if (!obj || typeof obj !== 'object') return false;
  const o = obj as Record<string, unknown>;
  return (
    typeof o.cursedEnergyType === 'string' &&
    o.innateTechnique !== null &&
    typeof o.innateTechnique === 'object' &&
    typeof (o.innateTechnique as Record<string, unknown>).name === 'string'
  );
}

function isValidClash(obj: unknown): obj is ClashResult {
  if (!obj || typeof obj !== 'object') return false;
  const o = obj as Record<string, unknown>;
  return typeof o.comboName === 'string';
}

export function useGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isClashing, setIsClashing] = useState(false);
  const { toast } = useToast();

  const generateTechnique = useCallback(async (params: GenerateParams): Promise<CursedTechniqueProfile | null> => {
    setIsGenerating(true);
    try {
      const response = await fetch("/api/cursed/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        throw new Error("Failed to generate technique");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          fullText += decoder.decode(value, { stream: true });
        }
      }

      const events = parseSSEEvents(fullText);
      const profile = events.find(isValidProfile) as CursedTechniqueProfile | undefined;

      if (profile) {
        return {
          ...profile,
          id: crypto.randomUUID(),
          timestamp: Date.now(),
        };
      }

      return null;
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [toast]);

  const clashTechniques = useCallback(async (profile1: CursedTechniqueProfile, profile2: CursedTechniqueProfile): Promise<ClashResult | null> => {
    setIsClashing(true);
    try {
      const response = await fetch("/api/cursed/clash", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          technique1: JSON.stringify(profile1),
          technique2: JSON.stringify(profile2),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to clash techniques");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          fullText += decoder.decode(value, { stream: true });
        }
      }

      const events = parseSSEEvents(fullText);
      const clash = events.find(isValidClash) as ClashResult | undefined;

      return clash ?? null;
    } catch (error) {
      toast({
        title: "Clash Error",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsClashing(false);
    }
  }, [toast]);

  return {
    generateTechnique,
    clashTechniques,
    isGenerating,
    isClashing,
  };
}
